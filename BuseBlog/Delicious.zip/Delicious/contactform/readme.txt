Fully working PHP/AJAX booking a table form is available in the pro version.
You can buy it from: https://bootstrapmade.com/buy/?theme=Delicious